package com.example.google_translator_deneme1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
